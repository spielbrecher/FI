<template>
  <div>
    <h2 class="text-center">Главная страница</h2>
  </div>
</template>

<script>

  export default {
    name: 'Home',

    components: {},
  }
</script>
