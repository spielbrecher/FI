<template>
  <div>
    <div class="d-flex body">
      <h2>Риск-профиль</h2>
      <h3>Скоро вы сможете пройти тестирование для улучшения качества использования нашего сервиса</h3>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
.body {
  flex-direction: column;
}
.body h2,
h3 {
  text-align: center;
}
</style>