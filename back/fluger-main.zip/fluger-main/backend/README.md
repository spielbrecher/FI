# Description of backend Fluger

**FI** - module for working with data of financial exchanges based on neural networks

Consist of:
- `model_generator.py` - class for gen model base on linear regression, random forest regression and mlp.
- `company.py` - class for set company params for subsequent model gen
- `main.py` - example of usage
Other files used to draw GUI 